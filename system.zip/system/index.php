<?php
    include "./backend/session_verification.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"> <!-- Bootstrap CSS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> <!-- Bootstrap Js -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- FontAwesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> <!-- Font Awesome Js -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- jQuery for AJAX -->
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
        <div class="sidebar p-3 text-white" style="background-color: #2E368F; width: 250px; min-height: 100vh;">
            <h3 class="text-center">Dashboard</h3>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="#" class="nav-link text-white menu-item" data-page="students">
                        <i class="fas fa-user-graduate"></i> Students
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-white menu-item" data-page="academics">
                        <i class="fas fa-book-open"></i> Academics
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link text-white menu-item" data-page="institution">
                        <i class="fas fa-university"></i> Institution
                    </a>
                </li>
                <li class="nav-item">
                    <a href="./backend/logout.php" class="nav-link text-white">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="content flex-grow-1 p-4">
            
            <div class="container" id="main-content">
                <div class="top-nav p-3 mb-3 text-center text-black" style="background-color: #FDD306; font-weight: bold;">
                    Welcome to Dashboard
                </div>

                <h2>Main Content</h2>
                <p>Select an option from the sidebar to load content dynamically.</p>
            </div>
        </div>
    </div>

    <script src="./script/main.js"></script>

</body>
</html>
