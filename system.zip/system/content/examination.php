<div>
    <h3>Examination</h3>
    <p>Information regarding exams, schedules, and results.</p>
</div>
