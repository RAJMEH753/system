<div>
    <h2>Students Section</h2>
    <p>Manage student records, view profiles, and track performance.</p>
</div>
