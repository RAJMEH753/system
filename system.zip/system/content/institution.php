<div>
    <h2>Institution Section</h2>
    <p>Manage institution details, departments, and policies.</p>
</div>
